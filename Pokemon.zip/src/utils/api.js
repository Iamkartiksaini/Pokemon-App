export const baseUrl = "https://pokeapi.co/api/v2/pokemon/";

export async function fetchPokemons() {
  const res = await fetch(`${baseUrl}?limit=20`);
  const data = await res.json();
  let pokemons = data.results;

  return pokemons;
}
