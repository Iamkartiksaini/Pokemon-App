import Link from "next/link";

export default function PokemonCard({ pokemon }) {
  const { image, name, url } = pokemon;
  const linkArr = url.split("/")
  const pokeId = linkArr[linkArr.length - 2]
  return (
    <div className="hover:scale-[1.1] transition-all shadow-black-50 flex flex-col gap-4 shadow-2xl rounded-lg py-4 px-6 m-2">
      {/* <img src={image} alt={name} className="w-32 h-32" /> */}
      <h3 className="text-xl">{name}</h3>
      <Link className="text-blue-500" href={`/pokemon/${pokeId}`}>
        View Details
      </Link>
    </div>
  );
}
