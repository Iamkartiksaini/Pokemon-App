"use client";
import { useState } from "react";

export default function SearchForm({ onSearch }) {
  const [type, setType] = useState("");
  const [search, setSearch] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    onSearch(type, search);
  };

  return (
    <form onSubmit={handleSubmit} className="mb-4">
      <select
        value={type}
        onChange={(e) => setType(e.target.value)}
        className="mr-2 p-2 border border-gray-300"
      >
        <option value="">All Types</option>
      </select>
      <input
        type="text"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search Pokémon"
        className="p-2 border border-gray-300"
      />
      <button type="submit" className="ml-2 p-2 rounded-sm bg-blue-500 text-white">
        Search
      </button>
    </form>
  );
}
