"use client"
import { useState, useEffect, Fragment } from 'react';
import SearchForm from '../components/SearchForm';
import PokemonCard from '../components/PokemonCard';
import { fetchPokemons } from '@/utils/api';

export default function Page() {
  const [pokemons, setPokemons] = useState([]);

  const handleSearch = async (type, search) => {
    const data = await fetchPokemons(type, search);
    setPokemons(data);
  };

  useEffect(() => {
    handleSearch('', '');
  }, []);

  function cardRender(data, index) {
    return <Fragment key={index}>
      <PokemonCard key={data.id} pokemon={data} />
    </Fragment>
  }

  return (
    <div className='p-4'>
      <SearchForm onSearch={handleSearch} />
      <div className="grid grid-cols-[repeat(auto-fill,minmax(250px,1fr))]">
        {pokemons.map(cardRender)}
      </div>
    </div>
  );
}
