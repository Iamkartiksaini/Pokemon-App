import Breadcrumb from '@/components/Breadcrumb'
import Link from 'next/link'
import React from 'react'

const Layout = ({ children }) => {
    return (
        <div className="flex flex-col justify-center gap-4 min-h-screen items-center">
            <div className="flex items-center  gap-4" >
                <Link className='border-2 hover:text-amber-600  hover:border-amber-600 py-1 px-3 m-0 h-fit  border-black rounded-sm' href={"/"}>Back</Link>
                <Breadcrumb />
            </div>
            {children}
        </div>
    )
}

export default Layout