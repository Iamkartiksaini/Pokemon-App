import { baseUrl } from '@/utils/api';

export default async function PokemonDetailsPage({ params }) {
    const { id } = await params;
    const res = await fetch(`${baseUrl}/${id}`);
    const data = await res.json();
    const { name, abilities, types, stats, moves, height, weight, sprites } = data;
    const threeMoves = [moves[0].move.name, moves[1].move.name, moves[2].move.name];
    const statsNames = stats.map(val => val.stat.name);
    const abilitNames = abilities.map(val => val.ability.name);
    const typesNames = types.map(val => val.type.name);

    return (
        <div>
            <div className='shadow-blue-400 rounded-lg overflow-hidden'>
                <div className="p-4 flex justify-center items-center bg-[#60e2c8]">
                    <img height={200} width={200} src={sprites.front_shiny} alt={name} />
                </div>
                <div className="p-4 bg-[#fdc767]">
                    <p><strong>Name:</strong> <span>{name}</span></p>
                    <p><strong>Types:</strong> <span>{typesNames.join(', ')}</span></p>
                    <p><strong>Stats:</strong> <span>{statsNames.join(', ')}</span></p>
                    <p><strong>Abilities:</strong> <span>{abilitNames.join(', ')}</span></p>
                    <p><strong>Some Moves:</strong> <span>{threeMoves.join(', ')}</span></p>
                </div>
            </div>
        </div>
    );
}
